sum2.js
sum3.js
使用了三方库，在 node 环境中打开
例如：

```
JavaScript1\src> node sum2.js
Big.js方法计算浮点数加
使用Big.js方法 0.1 + 0.2 的结果是 0.3
```
